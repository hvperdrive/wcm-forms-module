'use strict';

angular.module('forms_0.1.1.controllers')
    .controller('formsDetailController', [
        '$scope',
        '$rootScope',
        '$controller',
        '$templateCache',
        '$filter',
        '$window',
        'uuid4',

        // Services
        'LabelService',
        'configuration',

        // Factories
        'formsFactory',

        // Resolves
        'InstanceData',
        'ExternalForms',

        function($scope, $rootScope, $controller, $templateCache, $filter, $window, uuid4, LabelService, configuration, formsFactory, InstanceData, ExternalForms) {

            // Referencing the required factory
            $scope._factory = formsFactory;

            // Extend the default resource controller
            angular.extend(this, $controller('ResourceController', {$scope: $scope, InstanceData: InstanceData, Languages: []}));

            // ResourceView configuration
            $scope.context.type = LabelService.getString('Form'); // Set the current type to "Consumer"
            // Get server path for asset.
            $scope.serverPath = configuration.serverPath;

            $scope.publishedOptions = [{
                key: 'published',
                label: LabelService.getString('Published')
            }];

            $scope.data = {
                externalForms: ExternalForms.data
            };

            $scope.generateResponseFile = function generateResponseFile(type) {
                $window.open(configuration.serverPath + configuration.apiPrefix + configuration.apiLevel + 'forms/export?format=' + type || 'json', '_blank');
            };

            //
            // HIDE/SHOW
            //

            //
            // NEW FIELD
            //

            //
            // EDIT FIELD
            //

            //
            // SAVE FIELD
            //

            //
            // DELETE FIELD
            //

            //
            // OPTIONS
            //

            //
            // SUBMIT FORM
            //

            //
            // CUSTOM VALIDATIONS
            //

            //
            // CUSTOM FILTERS
            //

            // $scope events
            $scope.$on('$destroy', function() {
                $scope._newInstance = undefined;
                $scope._instance = undefined;
            });
        }
    ]);
