'use strict';

angular.module('forms_0.1.1.directives', []);
angular.module('forms_0.1.1.factories', []);
angular.module('forms_0.1.1.services', ['forms_0.1.1.factories']);
angular.module('forms_0.1.1.controllers', ['forms_0.1.1.services']);

angular.module('forms_0.1.1', [

    'pelorus.services',

    'forms_0.1.1.directives',
    'forms_0.1.1.factories',
    'forms_0.1.1.services',
    'forms_0.1.1.controllers'

    ])
    .run([function() {
        console.log('Forms module is available!');
    }]);
