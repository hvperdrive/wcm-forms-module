'use strict';

var Q = require('q');
var path = require('path');
var request = require('request');
var VariableHelper = require('app/helpers/modules/lib').Variables;

var getAllTemplates = function getAllTemplates() {
    var d = Q.defer();
    VariableHelper.getAll()
        .then(function(variables) {
            request({
                url: path.join(variables.domain, '/acpaas/form-survey-template/v' + variables.version + '/api/Templates'),
                headers: {
                    'tenantKey': variables.tenantKey
                }
            }, function(error, response, body) {
                if(error) {
                    return d.reject(error);
                }

                return d.resolve(body);
            });
        }, function onError(responseError) {
            d.reject(responseError);
        });

    return d.promise;
};
module.exports.getAllTemplates = getAllTemplates;
