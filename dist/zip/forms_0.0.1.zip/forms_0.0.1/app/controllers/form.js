'use strict';

require('rootpath')();
var _ = require('lodash');
var Q = require('q');
var FormModel = require('../models/form');
var Export = require('../helpers/export');
var ERROR_TYPES = require('app/middleware/errorInterceptor').ERROR_TYPES;
var formEngineHelper = require('../helpers/formEngine');

/**
 * @api {GET} /api/1.0.0/forms/ Get all forms.
 * @apiGroup Forms
 * @apiVersion 1.0.0
 *
 * @apiSuccess (200) {Object[]} Consumers200All Success
 *
 * @apiError (400) {Object} Error Bad request
 */
var read = function(req, res, next) {
    FormModel.find({
            'meta.deleted': false
        })
        .populate('meta.lastEditor')
        .lean()
        .exec(function(err, items) {
            if (!err && items) {
                res.status(200).json(items);
            } else {
                res.status(400).json({
                    err: err
                });
            }
        });
};
module.exports.read = read;

/**
 * @api {GET} /api/1.0.0/forms/:uuid/ Get a single form.
 * @apiGroup Forms
 * @apiParam {String} uuid Consumer uuid
 * @apiVersion 1.0.0
 *
 * @apiSuccess (200) {Object} Consumers200Single Success
 *
 * @apiError (400) {Object} Error Bad request
 */
var readOne = function(req, res, next) {
    if (!req.params.uuid) {
        return res.status(412).json({
            logType: ERROR_TYPES.NO_UUID,
            err: {
                msg: 'There is no uuid parameter specified!'
            }
        });
    }

    FormModel.findOne({
            uuid: req.params.uuid,
            'meta.deleted': false
        })
        .lean()
        .exec(function(err, items) {
            if (!err && items) {
                res.status(200).json(items);
            } else {
                res.status(400).json({
                    err: err
                });
            }
        });
};
module.exports.readOne = readOne;

/**
 * @api {GET} /api/1.0.0/forms/external Get a external forms.
 * @apiGroup Forms
 * @apiVersion 1.0.0
 *
 * @apiSuccess (200) {Object} Consumers200Single Success
 *
 * @apiError (400) {Object} Error Bad request
 */
var getExternal = function(req, res, next) {
    // TODO: Get all forms from the form & survey engine here and return a modified version of it.

    formEngineHelper.getAllTemplates()
        .then(function onSuccess(templates) {
            res.status(200).json(templates);
        }, function onError(err) {
            console.log(err);
            return res.status(500).json({
                msg: 'Could not get form templates from the form engine',
                err: err
            });
        });

    // Temp: return mocked Data
    res.status(200).json({
        'data': [{
            'name': 'Gezinssamenstelling',
            'description': 'Gezinssamenstelling formulier',
            'lookupKey': 'e13d2485-7eed-475b-8032-fc490953e4f0',
            'version': 'BB3CF8326E2A925AF7576B4FB9742367',
            'content': '{\'info\': {\'title\': \'Gezinssamenstelling\',\'body\': \'In het uittreksel gezinssamenstelling staat hoeveel personener officieel in uw gezin leven.\',},\'name\': \'UittrekselGezinssamenstelling\',\'formId\': \'\',\'canSaveDraft\' : true,\'saveOnNavigate\': false,\'rendererVersion\': \'1\',\'steps\': [],\'sections\': [],\'fields\': [],\'validators\': [{\'name\': \'myOwnReusableValidator\',\'type\': \'regexp\',\'options\': {\'pattern\': \'/^[1-9]|[1-9][0-9]+$/\'},\'errorMessage\': \'Gelieve enkel cijfers te gebruiken\'}]}',
            'creation': '2016-07-08T16:11:49.872207+02:00'
        }],
        'self': '/api/templates/e13d2485-7eed-475b-8032-fc490953e4f0/BB3CF8326E2A925AF7576B4FB9742367',
        'generation': {
            'timeStamp': '2016-07-08T16:14:05.7480173+02:00',
            'duration': 719
        },
        'feedback': null
    });
};
module.exports.getExternal = getExternal;

var mockResponses = {
    'data': [
        {
            'id': 'ab0c6889-578c-46d2-372b-08d3a73b73ed',
            'content': {
                'name': 'Valcke',
                'firstName': 'Jeroen',
                'address': {
                    'street': 'Mariakerksesteenweg',
                    'nr': 91,
                    'postalCode': 9031,
                    'city': 'Drongen',
                    'test': {
                        'la': 'lala'
                    }
                }

            },
            'templateLookupKey': 'b9fe9b16-5bd5-4224-a209-051ff4b30bb1',
            'templateVersion': '7ECD5AF20AA262FDD8A59DA1BAABDE57',
            'creation': '2016-07-08T16:23:37.312514+02:00'
        },
        {
            'id': 'ab0c6889-578c-46d2-372b-08d3a73b73ed',
            'content': {
                'name': 'Valcke',
                'firstName': 'Jeroen',
                'address': {
                    'street': 'Mariakerksesteenweg',
                    'nr': 91,
                    'postalCode': 9031,
                    'city': 'Drongen'
                }

            },
            'templateLookupKey': 'b9fe9b16-5bd5-4224-a209-051ff4b30bb1',
            'templateVersion': '7ECD5AF20AA262FDD8A59DA1BAABDE57',
            'creation': '2016-07-08T16:23:37.312514+02:00'
        }
    ],
    'self': '/api/responses/ab0c6889-578c-46d2-372b-08d3a73b73ed',
    'generation': {
        'timeStamp': '2016-07-08T16:25:04.2647019+02:00',
        'duration': 741
    },
    'feedback': null
};

var getResponses = function getResponses(req, res, next) {
    // TODO: Get all repsonses from a template

    res.status(200).json(mockResponses);
};
module.exports.getResponses = getResponses;

var generateResponsesFile = function generateResponsesFile(req, res, next) {
    var data = [];

    var flatten = function flatten(obj, result, prefix) {
        _.forEach(obj, function(v, k) {
            if(typeof v === 'string') {
                result[(prefix || '') + k] = v;
            } else if(typeof v === 'object' || Array.isArray(v)) {
                prefix += (k || 'parent') + '.';
                flatten(v, result, prefix);
            }
        });

        return result;
    };

    var mapResponse = function(type) {
        if(type === 'json') {
            return _.map(mockResponses.data, function(v, k) {
                return v.content;
            });
        }
        return _.map(mockResponses.data, function(v, k) {
            return flatten(v.content, {}, '');
        });
    };

    switch (req.query.format) {
        case 'xls':
            data = mapResponse(req.query.format);
            // Tell the browser to download this
            res.setHeader('Content-disposition', 'attachment; filename=responses.xls');
            res.setHeader('Content-type','application/vnd.ms-excel');

            return res.end(Export.xls(data), 'binary');
        case 'csv':
            data = mapResponse(req.query.format);
            // Tell the browser to download this
            res.setHeader('Content-disposition', 'attachment; filename=responses.csv');
            res.setHeader('Content-type','text/csv');

            return res.send(Export.csv(data));
        default:
            data = mapResponse(req.query.format);
            // Tell the browser to download this
            res.setHeader('Content-disposition', 'attachment; filename=responses.json');
            res.setHeader('Content-type','application/json');

            return res.send(data);

    }
};
module.exports.generateResponsesFile = generateResponsesFile;

/**
 * @api {PUT} /api/1.0.0/forms/:uuid/ Update a form.
 * @apiGroup Forms
 * @apiParam {String} uuid Form uuid
 * @apiVersion 1.0.0
 *
 * @apiSuccess (200) {Object} Consumers200Update Success
 * @apiSuccess (200) {String} Consumers200Update._id Mongo _id
 * @apiSuccess (200) {String} Consumers200Update.uuid Field type uuid
 * @apiSuccess (200) {Object} Consumers200Update.data Data
 * @apiSuccess (200) {Object} Consumers200Update.data.link Link
 * @apiSuccess (200) {String} Consumers200Update.data.link.description Description
 * @apiSuccess (200) {String} Consumers200Update.data.link.url URL
 * @apiSuccess (200) {Object} Consumers200Update.meta Metadata
 * @apiSuccess (200) {Date} Consumers200Update.meta.created Created at
 * @apiSuccess (200) {Boolean} Consumers200Update.meta.deleted Deleted
 * @apiSuccess (200) {Date} Consumers200Update.meta.lastModified Last modified at
 * @apiSuccess (200) {String} Consumers200Update.meta.lastEditor Last edited by
 * @apiSuccess (200) {Object[]} Consumers200Update.versions Versions
 *
 * @apiError (400) {Object} Error Bad request
 */
exports.update = function(req, res, next) {
    if (!req.params.uuid) {
        return res.status(400).json({
            logType: ERROR_TYPES.NO_UUID,
            err: 'There is no uuid parameter specified!'
        });
    }

    // Find userId to update to meta.lastEditor
    if (req.session.hasOwnProperty('profile')) {
        // Replace last editor _id
        req.body.meta.lastEditor = req.session.profile._id.toString();
    }

    FormModel.findOneAndUpdate({
            uuid: req.params.uuid
        }, req.body, {
            new: true
        })
        .then(
            function onSuccess(response) {
                res.status(200).json(response);
            },
            function onError(responseError) {
                res.status(400).json({
                    err: responseError
                });
            }
        );
};

/**
 * @api {POST} /api/1.0.0/forms/ Add a new form.
 * @apiGroup Forms
 * @apiVersion 1.0.0
 *
 * @apiSuccess (200) {Object} Consumers200Add Success
 * @apiSuccess (200) {String} Consumers200Add._id Mongo _id
 * @apiSuccess (200) {String} Consumers200Add.uuid Field type uuid
 * @apiSuccess (200) {Object} Consumers200Add.data Data
 * @apiSuccess (200) {Object} Consumers200Add.data.link Link
 * @apiSuccess (200) {String} Consumers200Add.data.link.description Description
 * @apiSuccess (200) {String} Consumers200Add.data.link.url URL
 * @apiSuccess (200) {Object} Consumers200Add.meta Metadata
 * @apiSuccess (200) {Date} Consumers200Add.meta.created Created at
 * @apiSuccess (200) {Boolean} Consumers200Add.meta.deleted Deleted
 * @apiSuccess (200) {Date} Consumers200Add.meta.lastModified Last modified at
 * @apiSuccess (200) {String} Consumers200Add.meta.lastEditor Last edited by
 * @apiSuccess (200) {Object[]} Consumers200Add.versions Versions
 *
 * @apiError (400) {Object} Error Bad request
 */
exports.create = function(req, res, next) {
    // Find userId to update to meta.lastEditor
    if (req.session.hasOwnProperty('profile')) {
        // Replace last editor _id
        req.body.meta.lastEditor = req.session.profile._id.toString();
    }

    FormModel.create(req.body)
        .then(
            function onSuccess(response) {
                res.status(200).json(response);
            },
            function onError(responseError) {
                res.status(400).json({
                    err: responseError
                });
            }
        );
};

/**
 * @api {DELETE} /api/1.0.0/forms/:uuid/ Delete a form
 * @apiParam {String} uuid Form uuid
 * @apiVersion 1.0.0
 *
 * @apiSuccess (204) Consumers204Delete No content
 *
 * @apiError (400) {Object} Error Bad request
 */
exports.delete = function(req, res, next) {
    if (!req.params.uuid) {
        return res.status(400).json({
            logType: ERROR_TYPES.NO_UUID,
            err: 'There is no uuid parameter specified!'
        });
    }

    var contentId;

    // Find the consumer id first, because we don't have the _id here.
    FormModel.findOne({
            uuid: req.params.uuid
        }, {
            _id: 1
        })
        .then(
            function onSuccess(response) {
                if (response) {
                    contentId = response._id;
                    return Q.when(response._id);
                } else {
                    throw 'Content item not found.';
                }
            }
        )
        .then(
            function deleteContent() {
                return FormModel.update({
                        uuid: req.params.uuid
                    }, {
                        $set: {
                            'meta.deleted': true
                        }
                    })
                    .exec();
            }
        )
        .then(
            function onSuccess() {
                res.status(204).send();
            },
            function onError(responseError) {
                res.status(400).json({
                    err: responseError
                });
            }
        );
};
